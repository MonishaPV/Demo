#!flask/bin/python


from flask import Flask, jsonify, abort, make_response, request
from flask_restful import Api, Resource, reqparse, fields, marshal
from flask_httpauth import HTTPBasicAuth
import requests
from requests.auth import HTTPBasicAuth as httpauth1
import urllib3
import json
from cmd import *

app = Flask(__name__, static_url_path="")
api = Api(app)
auth = HTTPBasicAuth()


tasks = [
    {
        'id': 1,
        'title': u'Temp File Deletion',
        'description': u'del /q/f/s %TEMP%\*',
        'done': False
	},
    {
        'id': 2,
        'title': u'Flush DNS',
        'description': u'ipconfig /flushdn',
        'done': False
    },
    {
        'id': 3,
        'title': u'GP Update',
        'description':u'gpupdate /force',
        'done': False
    },
	{
        'id': 4,
        'title': u'Outlook Clean Profile',
        'description': u'/cleanprofile',
        'done': False
    },
	{
        'id': 5,
        'title': u'Outlook Clean PST',
        'description': u'/cleanpst',
        'done': False
    },
	{
        'id': 6,
        'title': u'Outlook Clean reminders',
        'description': u'/cleanreminders',
        'done': False
    },
	{
        'id': 7,
        'title': u'Outlook Clean Rules',
        'description': u'/cleanrules',
        'done': False
    },
	{
        'id': 8,
        'title': u'Disk Clean UP',
        'description': u'cleanmgr.exe',
        'done': False
    },
	{
        'id': 9,
        'title': u'Check Disk',
        'description': u'chkdsk',
        'done': False
    },
	{
        'id': 10,
        'title': u'Internet Connectivity Check',
        'description': u'ping www.google.com',
        'done': False
    }
]

task_fields = {
    'title': fields.String,
    'description': fields.String,
    'done': fields.Boolean,
    'uri': fields.Url('task')
}


class TaskListAPI(Resource):

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('title', type=str, required=True,
                                   help='No task title provided',
                                   location='json')
        self.reqparse.add_argument('description', type=str, default="",
                                   location='json')
        super(TaskListAPI, self).__init__()

    def get(self):
        return {'tasks': [marshal(task, task_fields) for task in tasks]}




class TaskAPI(Resource):

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('title', type=str, location='json')
        self.reqparse.add_argument('description', type=str, location='json')
        self.reqparse.add_argument('done', type=bool, location='json')
        super(TaskAPI, self).__init__()

    def get(self, id):
        task = [task for task in tasks if task['id'] == id]
        if len(task) == 0:
            abort(404)
        return {'task': marshal(task[0], task_fields)}

		
class Itsm(Resource):

    def __init__(self):
        self.data = request.get_json()
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def post(self, name):
        if name == 'snow':
            uri = "https://hexawaretechnologiesincdemo1.service-now.com/incident.do?JSONv2"
            auth = httpauth1("RaiseIT", "RaiseIT")
            headers = {"Content-Type":"application/json","Accept":"application/json"}
            r = requests.post(url=uri, data=self.data, auth=auth, verify=False, headers=headers)
            content = r.json()
            assert (r.status_code == 200)
            #print ("Response Status Code: " + str(r.status_code))
            #print ("Response JSON Content: " + str(content))
            return { "Result" : "Ticket Created successfully for the Selected Option with Ticket ID - {0}".format(content['records'][0]['number']), "sys_id" : "{0}".format(content['records'][0]['sys_id'])}
        else:
            return {"Error" : "Given ITSM is not configured in server"}

        print(self.data)
		
    def put(self, name):
        print(self.data)
        print(f' Name : {name}')
        url = 'https://hexawaretechnologiesincdemo1.service-now.com/api/now/table/incident/{}'.format(name)
        auth = httpauth1("RaiseIT", "RaiseIT")
        headers = {"Content-Type":"application/json","Accept":"application/json"}
        response = requests.put(url, auth=auth, headers=headers ,data=self.data)
        if response.status_code != 200: 
            print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
        data = response.json()
        print(data)
        return data
		



api.add_resource(TaskListAPI, '/todo/api/v1.0/tasks', endpoint='tasks')
api.add_resource(TaskAPI, '/todo/api/v1.0/tasks/<int:id>', endpoint='task')
api.add_resource(Itsm, '/itsm/<string:name>')

if __name__ == '__main__':
    app.run(debug=True)

