/* This Node.js program execute a dialog chat with end user */
/* Based on the user input it will contact a centrel server and get the command to fix the end user issues */
/* This bot will execute the command in end user machine */ 
/* This bot will create an end point on local host and port 3978 */


//Initialise the required packages

module.exports.setup = function(app) {
var request = require('request');
var restify = require('restify');
var builder = require('botbuilder');
var http = require('http');
var path = require('path');
var os = require('os');
var teams = require("botbuilder-teams");
var keypress = require('keypress');
var fs = require('fs');
var config = require('config');
var botConfig = config.get('bot');

// Constant Variables

var sys_id;
var itsmdata = {
    "sysparm_action": "insert",
    "impact": "3",
    "urgency": "3",
	"priority": "5",
	"category": "TBR",
	"subcategory": "TBR",
    "short_description": "Testing Bot with Snow",
	"description": "Testing Bot with Snow",
	"assignment_group":"",
    "cmdb_ci": "chattest",
    "caller_id": "RAISE IT"
   }
  
var resolve_itsm = {
	   "work_notes": "Activity Completed successfully",
	   "state": "6"
	}
	
var reassign_itsm = {
		"impact": "2",
		"urgency": "2",
		"priority": "4",
		"state": "4",
		"assignment_group":"a0d1e5dd135a2200ab2cb5104244b0a5",
		"work_notes":"Failed to perform the operation hence reassigned the ticket"
   }
	

// Create chat connector for communicating with the Bot Framework Service
var connector = new teams.TeamsChatConnector({
        appId: process.env.MICROSOFT_APP_ID || botConfig.microsoftAppId,
        appPassword: process.env.MICROSOFT_APP_PASSWORD || botConfig.microsoftAppPassword
    });
    
var inMemoryBotStorage = new builder.MemoryBotStorage();

app.post('/api/messages', connector.listen());

//Initialize the bot
//var bot = new builder.UniversalBot(connector, {persistConversationData: true});
var userName = process.env['USERPROFILE'].split(path.sep)[2];


//Start the Conversation
/* bot.on('conversationUpdate', function (message) {  
   if (message.membersAdded[0].id === message.address.bot.id) {             
         var reply = new builder.Message()    
               .address(message.address)			   
               .text("Hello\t"+userName +"");        
         bot.send(reply);    
   }
});  */
var bot = new builder.UniversalBot(connector, function (session, args, results) 
{
	 //session.sendTyping(); 
	
	 if (!session.userData.name)
    {
	    console.log('Start conversation');
		name = session.message.text;
		session.userData.name = name;
		session.send("Hello ,"+userName +"\nI can help you with the following");
		//session.send("I can help you with the following")
		session.beginDialog('/main');
		
}
	else if(!session.userData.conformation)
    {
        console.log('execute command');
        dialog_flow(session);
    }
	dialog_flow(session);
}).set('storage', inMemoryBotStorage);


bot.dialog('/main',function (session, args, results) {
	 const card = new builder.ThumbnailCard(session)
            .title('Bot for Global Service Desk')
            .text(' You can choose one of the options below')
            .buttons([
                builder.CardAction.imBack(session,'Desktop Support','Desktop Support'),
                builder.CardAction.imBack(session, 'Outlook Support','Outlook Support'),
				 builder.CardAction.imBack(session, 'Network Support','Network Support')
            ]);
        const message = new builder.Message(session)
           .addAttachment(card)
        session.send(message);
		option = session.message.text;
		session.userData.option = option;
	
		
}
); 

/* bot.dialog('/main',function (session, args, results) {
var message = new builder.Message(session);
message.attachmentLayout(builder.AttachmentLayout.carousel);
var attachments = [
  new builder.HeroCard(session)
    .title("Bot for Global Service Desk")
    .text("You can choose one of the options below")
    .buttons([
      builder.CardAction.imBack(session, "Desktop Support", "Desktop Support"),
      builder.CardAction.imBack(session, "Outlook Support", "Outlook Support"),
      builder.CardAction.imBack(session, "Network Support", "Network Support"),
    ])
];
message.attachments(attachments);
session.send(message);
option = session.message.text;
session.userData.option = option;
}
);
 */

 bot.customAction({
	 
    matches:/desktop/gi,
		onSelectAction: (session, args, next) => {
		
		const card = new builder.ThumbnailCard(session)
						 .text("You have Selected Desktop Support")
						.buttons([
							builder.CardAction.imBack(session,'Fix a Slow Computer', 'Fix a Slow Computer'),
							builder.CardAction.imBack(session, 'Flush DNS', 'Flush DNS'),
							builder.CardAction.imBack(session, 'Refresh group policy ', 'Refresh group policy '),
							builder.CardAction.imBack(session,'Disk Clean Up', 'Disk Clean Up'),
							builder.CardAction.imBack(session, 'Check Disk', 'Check Disk')
						]);
					const message = new builder.Message(session)
						.addAttachment(card);
					session.send(message);
					option = session.message.text;
					session.userData.option = option;
					itsmdata["category"] = option;
					
}}
);

bot.customAction({
	matches:/Outlook/gi,
	
		
    onSelectAction: (session, args, next) => {
		
		const card = new builder.ThumbnailCard(session)
						 .text("You have Selected Outlook Support")
						.buttons([
							builder.CardAction.imBack(session, 'Clean Profile', 'Clean Profile'),
							builder.CardAction.imBack(session,'Clean PST', 'Clean PST'),
							builder.CardAction.imBack(session,'Clean Reminders', 'Clean Reminders'),
							builder.CardAction.imBack(session,'Clean Rules', 'Clean Rules')
						]);
					const message = new builder.Message(session)
						.addAttachment(card);
					session.send(message);
					option = session.message.text;
					session.userData.option = option;
					itsmdata["category"] = option;
					
					
}}
);
bot.customAction({
	
	matches:/Network/gi,
	
    onSelectAction: (session, args, next) => {
		
		const card = new builder.ThumbnailCard(session)
						 .text("You have Selected Network Support")
						.buttons([
							builder.CardAction.imBack(session,'Internet Connectivity Check','Internet Connectivity Check')
							
						]);
					const message = new builder.Message(session)
						.addAttachment(card);
					session.send(message);
					option = session.message.text
					itsmdata["category"] = option
					session.userData.option = option
			
					
}}
);

 bot.customAction({
    matches:/slow|Fix a Slow Computer|Flush DNS|flush|Refresh GP|Group Policy|Disk Clean UP|Check Disk|check disk|Internet Connectivity Check/gi,
		
	onSelectAction: (session, args, next) => {
	option = session.message.text
	itsmdata["subcategory"] = option
    session.userData.option = option
	session.send("You have Selected\t"+option+",\tPlease confirm?")
				const card = new builder.ThumbnailCard(session)
						.buttons([
							builder.CardAction.imBack(session, 'YES', 'YES'),
							builder.CardAction.imBack(session, 'NO', 'NO')
						]);
					const message = new builder.Message(session)
						.addAttachment(card);
					session.endConversation(message);
					
							}
    }
);

bot.dialog('/final',function (session, args, results) {
	
	
	const card = new builder.ThumbnailCard(session)
            .text('Do you want to Continue')
						.buttons([
							builder.CardAction.imBack(session, 'PROCEED', 'PROCEED'),
							builder.CardAction.imBack(session, 'EXIT', 'EXIT')
						]);
					const message = new builder.Message(session)
						.addAttachment(card);
					session.endConversation(message);
							}
	
);


function dialog_flow(session){
	 //session.sendTyping(); 
	conformation = session.message.text
    option = session.userData.option
    session.userData.conformation = conformation
    console.log('User Selected Option is %s', option);
    console.log('User conformation %', conformation);
	var proceedconfor = /proceed|Proceed/gi;
	var exitconfor = /exit|quit/gi;
	var yesconfor = /Yes|Y|ok/gi;
	var noconfor = /cancel|no|n|restart|reset|f5/gi;
	
	if(conformation.match(proceedconfor)){
		session.clearDialogStack();
		session.beginDialog('/main'); 
	}
    else if(conformation.match(exitconfor)){
		session.clearDialogStack();
		session.send("Thank you,\t Please Close the session");
		session.endDialog();
		session.userData = {};
	}
	else if(conformation.match(noconfor)){
		/* session.clearDialogStack();
		session.beginDialog('/main'); */
		session.reset('/main');
	}
    
   else if(conformation.match(yesconfor))
    {
		session.sendTyping();
		postdata(itsmdata, "snow", session);
		session.sendTyping(); 		
    }
}



// Endpoint declaration
function commandexec(session){
	 session.sendTyping(); 
	
	var endpoint = null;
        if( option =="Fix a Slow Computer")
        {
            console.info("Executed option is Temp files Cleanup ");
            endpoint = '/todo/api/v1.0/tasks/1'	
			
        } 
		else if (option =="Flush DNS"){
            
            console.info("Executed option is Flush DNS");
            endpoint = '/todo/api/v1.0/tasks/2'
        } 
        else if (option =="Refresh group policy "){
            console.info("Executed option is" +option);
            endpoint = '/todo/api/v1.0/tasks/3'		
        } 
		else if (option =="Clean Profile"){   
            console.info("Executed option is " +option);
            endpoint = '/todo/api/v1.0/tasks/4'
        } 
		else if (option =="Clean PST"){
            console.info("Executed option is" +option);
            endpoint = '/todo/api/v1.0/tasks/5'
        } 
		else if (option =="Clean Reminders"){
            
            console.info("Executed option is" +option);
            endpoint = '/todo/api/v1.0/tasks/6'
			
        } 
		else if (option =="Clean Rules"){
            
            console.info("Executed option is " +option);
            endpoint = '/todo/api/v1.0/tasks/7'
			
        } 
		else if (option =="Disk Clean Up"){
            
            console.info("Executed option is" +option);
            endpoint = '/todo/api/v1.0/tasks/8'
			
        } 
		else if(option =="Check Disk"){
            
            console.info("Executed option is " +option);
            endpoint = '/todo/api/v1.0/tasks/9'
			
        }
		else if(option =="Internet Connectivity Check"){
            
            console.info("Executed option is " +option);
            endpoint = '/todo/api/v1.0/tasks/10'
			
        }
		getData(endpoint, session, function (msg) {
			 //session.sendTyping(); 
            session.send(msg);
            //session.userData = null;
			
		 });	
}
 

/* function results(session){
		    session.send("Successfully Executed,"+option+"");
			putdata(resolve_itsm, sys_id);
			session.beginDialog('/final');
} */


// Command execution in cmd

function sendData(cmd, session, cb) {
  
    console.log("cmd = ", cmd)
    var process = require('child_process');
	
    process.exec(cmd,function (exitcode,stdout,stderr) {
  
	if (exitcode != null )
	{   
		session.sendTyping();
		session.send("Failed to perform,"+option+"");
		
		 //session.sendTyping(); 
		putdata(reassign_itsm, sys_id);
		 //session.sendTyping(); 
		session.beginDialog('/final');
	}
	else
	{     
		 session.send("Successfully Executed,"+option+"");
		  //session.sendTyping(); 
	      putdata(resolve_itsm, sys_id);
		   //session.sendTyping(); 
	      session.beginDialog('/final');
	}
    });
	
}

// API Calls

function getData(endpoint, session, cb)
{

// options for GET
var optionsget = {
    host : '127.0.0.1', 
    port : 5000,
    path : endpoint,
    method : 'GET' 
};

console.info('Options prepared:');
console.info(optionsget);
console.info('Do the GET call');

var reqGet = http.request(optionsget, function(res) {
    console.log("statusCode: ", res.statusCode);



    res.on('data', function(d) {
        console.info('GET result:\n');
        process.stdout.write(d);
        console.info(d)
		
       var obj = JSON.parse(d);
    
       var title = obj.task.title;
       console.log("title = ", title)
    
       cmd = obj.task.description;
       console.log("cmd = ", cmd)
       console.info('\n\nCall completed');
       
       sendData(cmd, session, function (msg) {
		    session.sendTyping(); 
            session.send(msg);
            session.userData = null;
        });
        
    });

});

reqGet.end();
reqGet.on('error', function(e) {
    console.error(e);
});

}

function postdata(json_data, itsm, session){
	var url = "http://localhost:5000/itsm/" + itsm;
	var data = {
		url: url,
		json: true,
		body: JSON.stringify(json_data)
	}
	request.post(data, function(error, httpResponse, body){
	sys_id = body.sys_id;
	session.send(body.Result)
	commandexec(session);
	});
}


function putdata(json_data, tic_id){

	var url = "http://localhost:5000/itsm/" + tic_id;
	var data = {
		url: url,
		json: true,
		body: JSON.stringify(json_data)
	}
	request.put(data, function(error, httpResponse, body){
		console.info("############################################")
		console.log("Ticket Updated Successfully");
		console.info("############################################")
	});
}

 module.exports.connector = connector;

};